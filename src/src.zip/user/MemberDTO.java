package user;

public class MemberDTO {

	private String id,name,password,email,phone,zipcode,address;



	public String getId() {
		return id == null ? "" : id.trim();
	}

	public void setId(String id) {

		this.id = id;

	}

	public String getName() {

		return name == null ? "" : name.trim();

	}

	public void setName(String name) {

		this.name = name;

	}

	public String getPassword() {

		return password == null ? "" : password.trim();

	}

	public void setPassword(String password) {

		this.password = password;

	}

	public String getEmail() {

		return email == null ? "" : email.trim();

	}

	public void setEmail(String email) {

		this.email = email;

	}

	public String getPhone() {
		return phone == null ? "" : phone.trim();
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getZipcode() {
		return zipcode == null ? "" : zipcode.trim();
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getAddress() {
		return address == null ? "" : address.trim();
	}

	public void setAddress(String address) {
		this.address = address;
	}

	

}