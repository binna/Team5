package user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDAO {
	private static MemberDAO instance = new MemberDAO();

	public static MemberDAO getInstance() {

		return instance;

	}

	private Connection getConnection() throws Exception {
		Context initCtx = new InitialContext();
		Context envCtx = (Context) initCtx.lookup("java:comp/env");
		DataSource ds = (DataSource) envCtx.lookup("jdbc/member");
		return ds.getConnection();
	}

	// ID 중복체크
	public int select_data(String word) {
		String val = null;

		Connection con = null;

		Statement st = null;

		ResultSet rs = null;
		try {
			String sql = "select * from member where id = '" + word + "'";
			System.out.println(sql);
			con = getConnection();
			st = con.createStatement();
			rs = st.executeQuery(sql);

			if (rs.next())
				val = rs.getString("PASSWORD");

			System.out.println("1:" + val);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeCon(con, st, rs);
		}
		System.out.println("2:" + val);
		if (val != null) {
			return 1;
		} else
			return 0;

	}

	// 집 주소 검색
	public ArrayList<AddressDTO> zipSearch(String dong) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		ArrayList<AddressDTO> arr = new ArrayList<>();
		try {
			con = getConnection();
			String sql = "select * from zipcode where DONG like '%" + dong + "%'";
			st = con.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				AddressDTO z = new AddressDTO();
				z.setZipcode(rs.getString("zipcode"));
				z.setSido(rs.getString("sido"));
				z.setGugun(rs.getString("gugun"));
				z.setDong(rs.getString("dong"));
				z.setBunji(rs.getString("bunji"));
				z.setSeq(rs.getInt("seq"));
				arr.add(z);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		}
		return arr;
	}

	// 회원가입

	public void joinInsert(MemberDTO dto) {

		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = getConnection();
			String sql = "insert into member values(?,?,?,?,?,?,?)";
			ps = con.prepareStatement(sql);

			ps.setString(1, dto.getId());
			System.out.println(dto.getId());

			ps.setString(2, dto.getPassword());
			System.out.println(dto.getPassword());

			ps.setString(3, dto.getName());
			System.out.println(dto.getName());

			ps.setString(4, dto.getZipcode());
			System.out.println(dto.getZipcode());

			ps.setString(5, dto.getPhone());
			System.out.println(dto.getPhone());

			ps.setString(6, dto.getEmail());
			System.out.println(dto.getEmail());

			ps.setString(7, dto.getAddress());
			System.out.println(dto.getAddress());

			ps.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();

		} finally {

			closeCon(con, ps);

		}

	}

	// �α���

	public int login_Check(String id, String password) {
		int result = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			String sql = "select password from member where id=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				if (rs.getString("password").equals(password)) {
					result = 1;
				} else if (!rs.getString("password").equals(password)) {
					result = 0;
				}
			} else {
				result = -1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeCon(con, ps);
		}
		return result;
	}

	// 정보수정
	public void Info_Update(String id, String name, String email, String phone, String zipcode, String address) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = getConnection();
			String sql = "update member set name= ? , email= ? , phone= ? , zipcode= ? , address= ? where id= ? ";

			ps = con.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, phone);
			ps.setString(4, zipcode);
			ps.setString(5, address);
			ps.setString(6, id);
			ps.executeQuery();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			closeCon(con, ps);
		}
	}

	public ArrayList<MemberDTO> memberList() {

		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		ArrayList<MemberDTO> arr = new ArrayList<>();
		try {
			con = getConnection();
			String sql = "select * from member";
			st = con.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				MemberDTO dto = new MemberDTO();
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				dto.setEmail(rs.getString("email"));
				dto.setPhone(rs.getString("phone"));
				dto.setZipcode(rs.getString("zipcode"));
				dto.setAddress(rs.getString("address"));
				arr.add(dto);

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeCon(con, st, rs);
		}
		return arr;
	}
	
	public void Delete(String id) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = getConnection();
			String sql = "delete from member where id= ? ";

			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ps.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeCon(con, ps);
		}
	}

	/*
	 * public MemberDTO memView(String id) {
	 * 
	 * Connection con = null;
	 * 
	 * Statement st = null;
	 * 
	 * ResultSet rs = null;
	 * 
	 * MemberDTO mem = null;
	 * 
	 * try {
	 * 
	 * con = getConnection();
	 * 
	 * String sql = "select * from member where id='" + id + "'";
	 * 
	 * st = con.createStatement();
	 * 
	 * rs = st.executeQuery(sql);
	 * 
	 * if (rs.next()) {
	 * 
	 * mem = new MemberDTO();
	 * 
	 * mem.setId(rs.getString("id"));
	 * 
	 * mem.setPassword(rs.getString("password"));
	 * 
	 * mem.setName(rs.getString("name"));
	 * 
	 * mem.setAge(rs.getInt("age"));
	 * 
	 * mem.setGender(rs.getString("gender"));
	 * 
	 * mem.setEmail(rs.getString("email"));
	 * 
	 * }
	 * 
	 * } catch (Exception e) {
	 * 
	 * e.printStackTrace();
	 * 
	 * } finally {
	 * 
	 * closeCon(con, st, rs);
	 * 
	 * }
	 * 
	 * return mem;
	 * 
	 * }
	 */
	/*
	 * // ��ü��ȸ
	 * 
	 * 
	 * 
	 * // Ż��
	 * 
	 * public void memDelete(String id) {
	 * 
	 * Connection con = null;
	 * 
	 * Statement st = null;
	 * 
	 * try {
	 * 
	 * con = getConnection();
	 * 
	 * st = con.createStatement();
	 * 
	 * String sql = "delete from member where id='" + id + "'";
	 * 
	 * st.executeUpdate(sql);
	 * 
	 * } catch (Exception e) {
	 * 
	 * e.printStackTrace();
	 * 
	 * } finally {
	 * 
	 * closeCon(con, st);
	 * 
	 * }
	 * 
	 * }
	 */
	private void closeCon(Connection con, PreparedStatement ps) {

		try {

			if (ps != null)
				ps.close();

			if (con != null)
				con.close();

		} catch (SQLException e) {

			e.printStackTrace();

		}

	}

	private void closeCon(Connection con, Statement st, ResultSet rs) {

		try {

			if (st != null)
				st.close();

			if (con != null)
				con.close();

			if (rs != null)
				rs.close();

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	

	
}